from django.apps import AppConfig


class ClienttrackerConfig(AppConfig):
    name = 'clienttracker'
